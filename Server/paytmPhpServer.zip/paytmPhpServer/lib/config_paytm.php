<?php
//Change the value of details received from Paytm based on merchent.
define('PAYTM_MERCHANT_KEY', 'G3s7OL8XkrX7Cd_8'); 
define('MID', 'GOLDSL30257208217900');
define('INDUSTRY_TYPE_ID', 'Retail');
define('CHANNEL_ID', 'WAP');
define('WEBSITE_STAGING', 'APP_STAGING'); //For staging
define('WEBSITE_PRODUCTION', 'APP_PRODUCTION'); //For staging
define('CALLBACK_URL', 'https://pguat.paytm.com/paytmchecksum/paytmCallback.jsp');
?>
