module.exports = {
  paytm_config: {
		MID: 'GOLDSL30257208217900',
		WEBSITE: 'goldslamsports.com',
    CHANNEL_ID: 'WAP',
    INDUSTRY_TYPE_ID: 'Retail',
    MERCHANT_KEY : 'G3s7OL8XkrX7Cd_8'
	}
}